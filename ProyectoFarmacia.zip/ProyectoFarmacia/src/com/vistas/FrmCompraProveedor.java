package com.vistas;

import com.dao.DaoCompraProveedor;
import com.modelo.CompraProveedor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *Nombre de la clase : FrmCompraProveedor
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class FrmCompraProveedor extends javax.swing.JInternalFrame {
    
    private static FrmCompraProveedor frmCompraProveedor;
    
    public static FrmCompraProveedor getInstancia(){
        if(frmCompraProveedor == null){
            frmCompraProveedor = new FrmCompraProveedor();
        }
        return frmCompraProveedor;
    }
    
    /**
     * Creates new form FrmCompraProveedor
     */
    public FrmCompraProveedor() {
        initComponents();
        tablaCompraProveedor();
    }
    
    CompraProveedor cp = new CompraProveedor();
    DaoCompraProveedor daocp = new DaoCompraProveedor();
    
    public void tablaCompraProveedor()
    {
        String [] columnas={"Id Compra","Id Proveedor","Fecha"};
        Object[] obj=new Object[3];
        DefaultTableModel tablas = new DefaultTableModel(null,columnas);
        List ls;
        try 
        {
            ls = daocp.mostrarCompraProveedor();
            for(int i=0;i<ls.size();i++)
            {
                cp=(CompraProveedor)ls.get(i);
                obj[0]=cp.getIdCompra();
                obj[1]=cp.getIdProveedor();
                obj[2]=cp.getFecha();
                tablas.addRow(obj);
            }
            
            ls = daocp.mostrarCompraProveedor();
            this.tabla.setModel(tablas);
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error al mostrar datos compraProveedor" + e.toString());
        }
    }
    
    public void llenarTabla(){
        int fila = this.tabla.getSelectedRow();
        this.txtIdCompra.setText(String.valueOf(this.tabla.getValueAt(fila, 0)));
        int cargo = Integer.parseInt(String.valueOf(this.tabla.getValueAt(fila, 1)));
        this.comboProveedor.getModel().setSelectedItem(cargo);
        this.txtFecha.setText(String.valueOf(this.tabla.getValueAt(fila, 2)));
    }
    
    public void limpiar(){
        this.txtIdCompra.setText("");
        this.comboProveedor.setSelectedIndex(0);
        this.txtFecha.setText("");
    }
    
    public void insertar() throws Exception{
        cp.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
        cp.setIdProveedor(Integer.parseInt(this.comboProveedor.getSelectedItem().toString()));
        cp.setFecha(this.txtFecha.getText());
        daocp.insertarCompraProveedor(cp);
        JOptionPane.showMessageDialog(null, "Datos insertados con exito");
        limpiar();
    }
    
    public void modificar()
    {
        try 
        {
            cp.setIdProveedor(Integer.parseInt(this.comboProveedor.getSelectedItem().toString()));
            cp.setFecha(this.txtFecha.getText());
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea modificar la compra al Proveedor",
                    "Modificar compra proveedor",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daocp.ModificarCompraProveedor(cp);
                JOptionPane.showMessageDialog(rootPane, "La Compra Proveedor sea modificado con exito",
                        "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaCompraProveedor();
                limpiar();
            }
            else
            {
                limpiar();
            }
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }
    
    public void eliminar()
    {
        try 
        {
            cp.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea eliminar La compra proveedor",
                    "Eliminar compra Proveedor",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daocp.EliminarCompraProveedor(cp);
                JOptionPane.showMessageDialog(rootPane,
                        "Eliminado con exito" , "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaCompraProveedor();
                limpiar();
            }
            else
            {
                limpiar();
            }
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(rootPane, e.toString(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        txtFecha = new javax.swing.JFormattedTextField();
        txtIdCompra = new javax.swing.JTextField();
        comboProveedor = new javax.swing.JComboBox<>();
        btnReporte = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabla);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Datos Compra al Proveedor");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("ID Compra :");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("ID Proveedor :");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Fecha :");

        btnInsertar.setText("Insertar");
        btnInsertar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnInsertarMouseClicked(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnModificarMouseClicked(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });

        try {
            txtFecha.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtIdCompra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdCompraKeyTyped(evt);
            }
        });

        comboProveedor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2" }));

        btnReporte.setText("Reporte");
        btnReporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnReporteMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btnInsertar)
                        .addGap(55, 55, 55)
                        .addComponent(btnModificar)
                        .addGap(52, 52, 52)
                        .addComponent(btnEliminar)
                        .addGap(48, 48, 48)
                        .addComponent(btnLimpiar)
                        .addGap(33, 33, 33)
                        .addComponent(btnReporte))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(217, 217, 217)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(txtIdCompra, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtFecha)
                                .addComponent(comboProveedor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 601, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(comboProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar)
                    .addComponent(btnLimpiar)
                    .addComponent(btnReporte))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        llenarTabla();
    }//GEN-LAST:event_tablaMouseClicked

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        limpiar();
    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void txtIdCompraKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdCompraKeyTyped
        Character s = evt.getKeyChar();
        if(!Character.isDigit(s)){
            evt.consume();
        }
    }//GEN-LAST:event_txtIdCompraKeyTyped

    private void btnInsertarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInsertarMouseClicked
        try
        {
            insertar();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        tablaCompraProveedor();
    }//GEN-LAST:event_btnInsertarMouseClicked

    private void btnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnModificarMouseClicked
        modificar();
    }//GEN-LAST:event_btnModificarMouseClicked

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        eliminar();
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void btnReporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReporteMouseClicked
        Connection conexion = null;
        JasperReport reporte;
        
        try 
        {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmacia",
                    "root",
                    "");
        }
        catch (ClassNotFoundException | SQLException e)
        {
            System.out.println(e.getMessage());
        }
        try 
        {
            reporte = JasperCompileManager.compileReport("src/com/reportes/reporteCompraProveedor.jrxml");
            JasperPrint jp = JasperFillManager.fillReport(reporte,null,conexion);
            JasperViewer.viewReport(jp, false);
        }
        catch (JRException ex)
        {
            Logger.getLogger(FrmCompraProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReporteMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnReporte;
    private javax.swing.JComboBox<String> comboProveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabla;
    private javax.swing.JFormattedTextField txtFecha;
    private javax.swing.JTextField txtIdCompra;
    // End of variables declaration//GEN-END:variables
}
