package com.vistas;

import com.conexion.Conexion;
import javax.swing.JOptionPane;

/**
 *Nombre de la clase : Test
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class Test {
    public static void main(String[] args) {
        Conexion con = new Conexion();
        JOptionPane.showMessageDialog(null, "Conecto?" + con.conectar());
    }
}
