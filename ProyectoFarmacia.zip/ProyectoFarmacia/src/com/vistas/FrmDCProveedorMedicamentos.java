package com.vistas;

import com.dao.DaoDCProveedorMedicamentos;
import com.modelo.DCProveedorMedicamentos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *Nombre de la clase : FrmDCProveedorMedicamentos
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class FrmDCProveedorMedicamentos extends javax.swing.JInternalFrame {

    private static FrmDCProveedorMedicamentos frmDCProveedorMedicamentos;
    
    public static FrmDCProveedorMedicamentos getInstancia(){
        if(frmDCProveedorMedicamentos == null){
            frmDCProveedorMedicamentos = new FrmDCProveedorMedicamentos();
        }
        return frmDCProveedorMedicamentos;
    }
    
    /**
     * Creates new form FrmDCProveedorMedicamentos
     */
    public FrmDCProveedorMedicamentos() {
        initComponents();
        tablaDCProveedorMedicamentos();
    }
    
    DCProveedorMedicamentos dcpm = new DCProveedorMedicamentos();
    DaoDCProveedorMedicamentos daod = new DaoDCProveedorMedicamentos();
    
    public void tablaDCProveedorMedicamentos(){
        String [] columnas={"Id Compra","Id Medicamento","Cantidad","Descripcion"};
        Object[] obj=new Object[4];
        DefaultTableModel tablas = new DefaultTableModel(null,columnas);
        List ls;
        try 
        {
            ls = daod.mostrarDCProveedorMedicamentos();
            for(int i=0;i<ls.size();i++)
            {
                dcpm=(DCProveedorMedicamentos)ls.get(i);
                obj[0]=dcpm.getIdCompra();
                obj[1]=dcpm.getIdMedicamento();
                obj[2]=dcpm.getCantidad();
                obj[3]=dcpm.getDescripcion();
                tablas.addRow(obj);
            }
            
            ls = daod.mostrarDCProveedorMedicamentos();
            this.tabla.setModel(tablas);
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error al mostrar datos Detalle compra Proveedor Medicamentos" + e.toString());
        }
    }
    
    public void llenarTabla(){
        int fila = this.tabla.getSelectedRow();
        this.txtIdCompra.setText(String.valueOf(this.tabla.getValueAt(fila, 0)));
        this.txtIdMedicamento.setText(String.valueOf(this.tabla.getValueAt(fila, 1)));
        int cantidad = Integer.parseInt(String.valueOf(this.tabla.getValueAt(fila, 2)));
        this.sCantidad.setValue(cantidad);
        this.txtDescripcion.setText(String.valueOf(this.tabla.getValueAt(fila, 3)));
    }
    
    public void limpiar(){
        this.txtIdCompra.setText("");
        this.txtIdMedicamento.setText("");
        this.sCantidad.setValue(1);
        this.txtDescripcion.setText("");
    }
    
    public void insertar() throws Exception{
        dcpm.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
        dcpm.setIdMedicamento(Integer.parseInt(this.txtIdMedicamento.getText()));
        dcpm.setCantidad(Integer.parseInt(this.sCantidad.getValue().toString()));
        dcpm.setDescripcion(this.txtDescripcion.getText());
        daod.insertarDCProveedorMedicamentos(dcpm);
        JOptionPane.showMessageDialog(null, "Datos insertados con exito");
        limpiar();
    }
    
    public void modificar()
    {
        try 
        {
            dcpm.setIdMedicamento(Integer.parseInt(this.txtIdMedicamento.getText()));
            dcpm.setCantidad(Integer.parseInt(this.sCantidad.getValue().toString()));
            dcpm.setDescripcion(this.txtDescripcion.getText());
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea modificar el detalle compra al Proveedor",
                    "Modificar el detalle compra",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daod.ModificarDCProveedorMedicamentos(dcpm);
                JOptionPane.showMessageDialog(rootPane, "El detalle compra proveedor sea modificado con exito",
                        "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaDCProveedorMedicamentos();
                limpiar();
            }
            else
            {
                limpiar();
            }
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }
    
    public void eliminar()
    {
        try 
        {
            dcpm.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea eliminar el detalle compra Proveedor",
                    "Eliminar el detalle compra proveedor",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daod.eliminarDCProveedorMedicamentos(dcpm);
                JOptionPane.showMessageDialog(rootPane,
                        "Eliminado con exito" , "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaDCProveedorMedicamentos();
                limpiar();
            }
            else
            {
                limpiar();
            }
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(rootPane, e.toString(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtIdCompra = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btnReporte = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar2 = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        txtIdMedicamento = new javax.swing.JTextField();
        sCantidad = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();

        setClosable(true);
        setIconifiable(true);

        txtIdCompra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdCompraKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Detalle Compra al Proveedor Medicamentos");

        btnReporte.setText("Reporte");
        btnReporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnReporteMouseClicked(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("ID Compra :");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("ID Medicamento :");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Cantidad :");

        btnInsertar.setText("Insertar");
        btnInsertar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnInsertarMouseClicked(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnModificarMouseClicked(evt);
            }
        });

        btnEliminar2.setText("Eliminar");
        btnEliminar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminar2MouseClicked(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabla);

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("Descripción :");

        txtIdMedicamento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdMedicamentoKeyTyped(evt);
            }
        });

        sCantidad.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane1.setViewportView(txtDescripcion);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btnInsertar)
                        .addGap(55, 55, 55)
                        .addComponent(btnModificar)
                        .addGap(52, 52, 52)
                        .addComponent(btnEliminar2)
                        .addGap(48, 48, 48)
                        .addComponent(btnLimpiar)
                        .addGap(33, 33, 33)
                        .addComponent(btnReporte))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 601, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(sCantidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                .addComponent(txtIdMedicamento, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtIdCompra, javax.swing.GroupLayout.Alignment.LEADING)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(158, 158, 158))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtIdMedicamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(sCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar2)
                    .addComponent(btnLimpiar)
                    .addComponent(btnReporte))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdCompraKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdCompraKeyTyped
        Character s = evt.getKeyChar();
        if(!Character.isDigit(s)){
            evt.consume();
        }
    }//GEN-LAST:event_txtIdCompraKeyTyped

    private void btnReporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReporteMouseClicked
        Connection conexion = null;
        JasperReport reporte;

        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmacia",
                "root",
                "");
        }
        catch (ClassNotFoundException | SQLException e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            reporte = JasperCompileManager.compileReport("src/com/reportes/reporteDetalleMedicamento.jrxml");
            JasperPrint jp = JasperFillManager.fillReport(reporte,null,conexion);
            JasperViewer.viewReport(jp, false);
        }
        catch (JRException ex)
        {
            Logger.getLogger(FrmDCProveedorMedicamentos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReporteMouseClicked

    private void btnInsertarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInsertarMouseClicked
        try
        {
            insertar();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        tablaDCProveedorMedicamentos();
    }//GEN-LAST:event_btnInsertarMouseClicked

    private void btnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnModificarMouseClicked
        modificar();
    }//GEN-LAST:event_btnModificarMouseClicked

    private void btnEliminar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminar2MouseClicked
        eliminar();
    }//GEN-LAST:event_btnEliminar2MouseClicked

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        limpiar();
    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        llenarTabla();
    }//GEN-LAST:event_tablaMouseClicked

    private void txtIdMedicamentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdMedicamentoKeyTyped
        Character s = evt.getKeyChar();
        if(!Character.isDigit(s)){
            evt.consume();
        }
    }//GEN-LAST:event_txtIdMedicamentoKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar2;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnReporte;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner sCantidad;
    private javax.swing.JTable tabla;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextField txtIdCompra;
    private javax.swing.JTextField txtIdMedicamento;
    // End of variables declaration//GEN-END:variables
}
