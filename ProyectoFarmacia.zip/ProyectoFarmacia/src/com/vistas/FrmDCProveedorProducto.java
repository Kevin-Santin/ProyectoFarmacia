package com.vistas;

import com.dao.DaoDCProveedorProducto;
import com.modelo.DCProveedorProducto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author kevin
 */
public class FrmDCProveedorProducto extends javax.swing.JInternalFrame {

    private static FrmDCProveedorProducto frmDCProveedorProducto;
    
    public static FrmDCProveedorProducto getInstancia(){
        if(frmDCProveedorProducto == null){
            frmDCProveedorProducto = new FrmDCProveedorProducto();
        }
        return frmDCProveedorProducto;
    }
    
    /**
     * Creates new form FrmDCProveedorProducto
     */
    public FrmDCProveedorProducto() {
        initComponents();
        tablaDCProveedorProductos();
    }
    
    DCProveedorProducto dcpp = new DCProveedorProducto();
    DaoDCProveedorProducto daop = new DaoDCProveedorProducto();
    
    public void tablaDCProveedorProductos(){
        String [] columnas={"Id Compra","Id Producto","Cantidad","Descripcion"};
        Object[] obj=new Object[4];
        DefaultTableModel tablas = new DefaultTableModel(null,columnas);
        List ls;
        try 
        {
            ls = daop.mostrarDCProveedorProducto();
            for(int i=0;i<ls.size();i++)
            {
                dcpp=(DCProveedorProducto)ls.get(i);
                obj[0]=dcpp.getIdCompra();
                obj[1]=dcpp.getIdProducto();
                obj[2]=dcpp.getCantidad();
                obj[3]=dcpp.getDescripcion();
                tablas.addRow(obj);
            }
            
            ls = daop.mostrarDCProveedorProducto();
            this.tabla.setModel(tablas);
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(this, "Error al mostrar datos Detalle compra Proveedor Productos" + e.toString());
        }
    }
    
    public void llenarTabla(){
        int fila = this.tabla.getSelectedRow();
        this.txtIdCompra.setText(String.valueOf(this.tabla.getValueAt(fila, 0)));
        this.txtIdProducto.setText(String.valueOf(this.tabla.getValueAt(fila, 1)));
        int cantidad = Integer.parseInt(String.valueOf(this.tabla.getValueAt(fila, 2)));
        this.sCantidad.setValue(cantidad);
        this.txtDescripcion.setText(String.valueOf(this.tabla.getValueAt(fila, 3)));
    }
    
    public void limpiar(){
        this.txtIdCompra.setText("");
        this.txtIdProducto.setText("");
        this.sCantidad.setValue(1);
        this.txtDescripcion.setText("");
    }
    
    public void insertar() throws Exception{
        dcpp.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
        dcpp.setIdProducto(Integer.parseInt(this.txtIdProducto.getText()));
        dcpp.setCantidad(Integer.parseInt(this.sCantidad.getValue().toString()));
        dcpp.setDescripcion(this.txtDescripcion.getText());
        daop.insertarDCProveedorProductos(dcpp);
        JOptionPane.showMessageDialog(null, "Datos insertados con exito");
        limpiar();
    }
    
    public void modificar()
    {
        try 
        {
            dcpp.setIdProducto(Integer.parseInt(this.txtIdProducto.getText()));
            dcpp.setCantidad(Integer.parseInt(this.sCantidad.getValue().toString()));
            dcpp.setDescripcion(this.txtDescripcion.getText());
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea modificar el detalle compra al Proveedor",
                    "Modificar el detalle compra",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daop.modificarDCProveedorProductos(dcpp);
                JOptionPane.showMessageDialog(rootPane, "El detalle compra proveedor sea modificado con exito",
                        "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaDCProveedorProductos();
                limpiar();
            }
            else
            {
                limpiar();
            }
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }
    
    public void eliminar()
    {
        try 
        {
            dcpp.setIdCompra(Integer.parseInt(this.txtIdCompra.getText()));
            int SioNo=JOptionPane.showConfirmDialog(this,
                    "Desea eliminar el detalle compra Proveedor",
                    "Eliminar el detalle compra proveedor",JOptionPane.YES_NO_OPTION);
            if(SioNo==0)
            {
                daop.eliminarDCProveedorProductos(dcpp);
                JOptionPane.showMessageDialog(rootPane,
                        "Eliminado con exito" , "Confirmación",
                        JOptionPane.INFORMATION_MESSAGE);
                tablaDCProveedorProductos();
                limpiar();
            }
            else
            {
                limpiar();
            }
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(rootPane, e.toString(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sCantidad = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        btnInsertar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar2 = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        txtIdCompra = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnReporte = new javax.swing.JButton();
        txtIdProducto = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);

        sCantidad.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setText("ID Producto :");

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane1.setViewportView(txtDescripcion);

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Cantidad :");

        btnInsertar.setText("Insertar");
        btnInsertar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnInsertarMouseClicked(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnModificarMouseClicked(evt);
            }
        });

        btnEliminar2.setText("Eliminar");
        btnEliminar2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminar2MouseClicked(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLimpiarMouseClicked(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabla);

        txtIdCompra.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdCompraKeyTyped(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Detalle Compra al Proveedor Productos");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("Descripción :");

        btnReporte.setText("Reporte");
        btnReporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnReporteMouseClicked(evt);
            }
        });

        txtIdProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtIdProductoKeyTyped(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel2.setText("ID Compra :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(btnInsertar)
                        .addGap(55, 55, 55)
                        .addComponent(btnModificar)
                        .addGap(52, 52, 52)
                        .addComponent(btnEliminar2)
                        .addGap(48, 48, 48)
                        .addComponent(btnLimpiar)
                        .addGap(33, 33, 33)
                        .addComponent(btnReporte))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 601, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(sCantidad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                .addComponent(txtIdProducto, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtIdCompra, javax.swing.GroupLayout.Alignment.LEADING)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(158, 158, 158))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtIdCompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtIdProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(sCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInsertar)
                    .addComponent(btnModificar)
                    .addComponent(btnEliminar2)
                    .addComponent(btnLimpiar)
                    .addComponent(btnReporte))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnInsertarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnInsertarMouseClicked
        try
        {
            insertar();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        tablaDCProveedorProductos();
    }//GEN-LAST:event_btnInsertarMouseClicked

    private void btnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnModificarMouseClicked
        modificar();
    }//GEN-LAST:event_btnModificarMouseClicked

    private void btnEliminar2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminar2MouseClicked
        eliminar();
    }//GEN-LAST:event_btnEliminar2MouseClicked

    private void btnLimpiarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMouseClicked
        limpiar();
    }//GEN-LAST:event_btnLimpiarMouseClicked

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        llenarTabla();
    }//GEN-LAST:event_tablaMouseClicked

    private void txtIdCompraKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdCompraKeyTyped
        Character s = evt.getKeyChar();
        if(!Character.isDigit(s)){
            evt.consume();
        }
    }//GEN-LAST:event_txtIdCompraKeyTyped

    private void btnReporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnReporteMouseClicked
        Connection conexion = null;
        JasperReport reporte;

        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmacia",
                "root",
                "");
        }
        catch (ClassNotFoundException | SQLException e)
        {
            System.out.println(e.getMessage());
        }
        try
        {
            reporte = JasperCompileManager.compileReport("src/com/reportes/reporteDetalleProducto.jrxml");
            JasperPrint jp = JasperFillManager.fillReport(reporte,null,conexion);
            JasperViewer.viewReport(jp, false);
        }
        catch (JRException ex)
        {
            Logger.getLogger(FrmDCProveedorProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnReporteMouseClicked

    private void txtIdProductoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdProductoKeyTyped
        Character s = evt.getKeyChar();
        if(!Character.isDigit(s)){
            evt.consume();
        }
    }//GEN-LAST:event_txtIdProductoKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar2;
    private javax.swing.JButton btnInsertar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnReporte;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner sCantidad;
    private javax.swing.JTable tabla;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextField txtIdCompra;
    private javax.swing.JTextField txtIdProducto;
    // End of variables declaration//GEN-END:variables
}
