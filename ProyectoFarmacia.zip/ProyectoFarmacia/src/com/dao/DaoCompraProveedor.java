package com.dao;

import com.conexion.Conexion;
import com.modelo.CompraProveedor;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *Nombre de la clase : DaoCompraProveedor
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class DaoCompraProveedor extends Conexion{
    public String insertarCompraProveedor(CompraProveedor cp){
        try 
        {
            this.conectar();
            String sql="insert into compraProveedor values(?,?,?);";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,cp.getIdCompra());
            pre.setInt(2,cp.getIdProveedor());
            pre.setString(3,cp.getFecha());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al insertar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Insertado Correctamente";
    }
    public String ModificarCompraProveedor(CompraProveedor cp){
        try 
        {
            this.conectar();
            String sql="update compraProveedor set idProveedor=?, fecha=? where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,cp.getIdProveedor());
            pre.setString(2,cp.getFecha());
            pre.setInt(3,cp.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al Modificar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Modificado Correctamente";
    }
    public String EliminarCompraProveedor(CompraProveedor cp){
        try 
        {
            this.conectar();
            String sql="delete from compraProveedor where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,cp.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al Eliminar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Eliminado Correctamente";
    }
    public List<CompraProveedor> mostrarCompraProveedor() throws Exception
    {
       ResultSet rs;
       List<CompraProveedor>lst=new ArrayList();
        try 
        {
            this.conectar();
            String sql="select * from compraProveedor;";
            PreparedStatement pst=this.getCon().prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next())
            {
                CompraProveedor cp = new CompraProveedor();
                cp.setIdCompra(rs.getInt("idCompra"));
                cp.setIdProveedor(rs.getInt("idProveedor"));
                cp.setFecha(rs.getString("fecha"));
                lst.add(cp);
            }
        }
        catch (Exception e) 
        {
            throw e;
        }
        finally
        {
            this.desconectar();
        }
        return lst;
    }
}
