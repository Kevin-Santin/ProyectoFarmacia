package com.dao;

import com.conexion.Conexion;
import com.modelo.DCProveedorProducto;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *Nombre de la clase : DaoDCProveedorProducto
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class DaoDCProveedorProducto extends Conexion{
    public String insertarDCProveedorProductos(DCProveedorProducto dcpp){
        try 
        {
            this.conectar();
            String sql="insert into DCProveedorProductos values(?,?,?,?);";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpp.getIdCompra());
            pre.setInt(2,dcpp.getIdProducto());
            pre.setInt(3,dcpp.getCantidad());
            pre.setString(4,dcpp.getDescripcion());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al insertar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Insertado Correctamente";
    }
    public String modificarDCProveedorProductos(DCProveedorProducto dcpp){
        try 
        {
            this.conectar();
            String sql="update DCProveedorProductos set idProducto=?, cantidad=?, descripcion=? where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpp.getIdProducto());
            pre.setInt(2,dcpp.getCantidad());
            pre.setString(3,dcpp.getDescripcion());
            pre.setInt(4,dcpp.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al modificar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Modificado Correctamente";
    }
    public String eliminarDCProveedorProductos(DCProveedorProducto dcpp){
        try 
        {
            this.conectar();
            String sql="delete from DCProveedorProductos where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpp.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al eliminar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Eliminado Correctamente";
    }
    
    public List<DCProveedorProducto> mostrarDCProveedorProducto() throws Exception
    {
       ResultSet rs;
       List<DCProveedorProducto>lst=new ArrayList();
        try 
        {
            this.conectar();
            String sql="select * from DCProveedorProductos;";
            PreparedStatement pst=this.getCon().prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next())
            {
                DCProveedorProducto dcpp = new DCProveedorProducto();
                dcpp.setIdCompra(rs.getInt("idCompra"));
                dcpp.setIdProducto(rs.getInt("idProducto"));
                dcpp.setCantidad(rs.getInt("cantidad"));
                dcpp.setDescripcion(rs.getString("descripcion"));
                lst.add(dcpp);
            }
        }
        catch (Exception e) 
        {
            throw e;
        }
        finally
        {
            this.desconectar();
        }
        return lst;
    }
    
}
