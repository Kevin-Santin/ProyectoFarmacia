package com.dao;

import com.conexion.Conexion;
import com.modelo.DCProveedorMedicamentos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *Nombre de la clase : DaoDCProveedorMedicamentos
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class DaoDCProveedorMedicamentos extends Conexion{
    public String insertarDCProveedorMedicamentos(DCProveedorMedicamentos dcpm){
        try 
        {
            this.conectar();
            String sql="insert into DCProveedorMedicamentos values(?,?,?,?);";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpm.getIdCompra());
            pre.setInt(2,dcpm.getIdMedicamento());
            pre.setInt(3,dcpm.getCantidad());
            pre.setString(4,dcpm.getDescripcion());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al insertar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Insertado Correctamente";
    }
    public String ModificarDCProveedorMedicamentos(DCProveedorMedicamentos dcpm){
        try 
        {
            this.conectar();
            String sql="update DCProveedorMedicamentos set idMedicamento=?, cantidad=?, descripcion=? where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpm.getIdMedicamento());
            pre.setInt(2,dcpm.getCantidad());
            pre.setString(3,dcpm.getDescripcion());
            pre.setInt(4,dcpm.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al Modificar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Modificado Correctamente";
    }
    public String eliminarDCProveedorMedicamentos(DCProveedorMedicamentos dcpm){
        try 
        {
            this.conectar();
            String sql="delete from DCProveedorMedicamentos where idCompra=?;";
            PreparedStatement pre =this.getCon().prepareStatement(sql);
            pre.setInt(1,dcpm.getIdCompra());
            pre.executeUpdate();
        }
        catch (SQLException e) 
        {
            JOptionPane.showMessageDialog(null,
                "Error al Eliminar "+e);
        }
        finally
        {
            this.desconectar();
        }
        return "Eliminado Correctamente";
    }
    
    public List<DCProveedorMedicamentos> mostrarDCProveedorMedicamentos() throws Exception
    {
       ResultSet rs;
       List<DCProveedorMedicamentos>lst=new ArrayList();
        try 
        {
            this.conectar();
            String sql="select * from DCProveedorMedicamentos;";
            PreparedStatement pst=this.getCon().prepareStatement(sql);
            rs=pst.executeQuery();
            while(rs.next())
            {
                DCProveedorMedicamentos dcpm = new DCProveedorMedicamentos();
                dcpm.setIdCompra(rs.getInt("idCompra"));
                dcpm.setIdMedicamento(rs.getInt("idMedicamento"));
                dcpm.setCantidad(rs.getInt("cantidad"));
                dcpm.setDescripcion(rs.getString("descripcion"));
                lst.add(dcpm);
            }
        }
        catch (Exception e) 
        {
            throw e;
        }
        finally
        {
            this.desconectar();
        }
        return lst;
    }
}
