package com.modelo;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

/**
 *Nombre de la clase : CompraProveedor
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class CompraProveedor {
    private int idCompra;
    private int idProveedor;
    private String fecha;

    //metodo constructor
    public CompraProveedor() {
    }
    
    // AQUI PARA SOLO ABRIR UNA VES EL FORMULARIO
    public static JDesktopPane jDesktopPane;

    public CompraProveedor(JDesktopPane JDesktopPane) {
        CompraProveedor.jDesktopPane = JDesktopPane;
    }
    
    public void abrirCompraProveedor(JInternalFrame jInternalFrame){
        if(jInternalFrame.isVisible()){
            jInternalFrame.toFront();
            jInternalFrame.requestFocus();
        }else{
            jDesktopPane.add(jInternalFrame);
            jInternalFrame.setVisible(true);
        }
    }
    //HASTA AQUI

    //metodo constructor con parametros
    public CompraProveedor(int idCompra, int idProveedor, String fecha) {
        this.idCompra = idCompra;
        this.idProveedor = idProveedor;
        this.fecha = fecha;
    }
    //get y set
    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}
