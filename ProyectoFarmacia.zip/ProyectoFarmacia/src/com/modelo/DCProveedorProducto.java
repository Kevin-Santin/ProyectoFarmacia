package com.modelo;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

/**
 *Nombre de la clase : DCProveedorProducto
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class DCProveedorProducto {
    private int idCompra;
    private int idProducto;
    private int cantidad;
    private String descripcion;

    public DCProveedorProducto() {
    }
    
    // AQUI PARA SOLO ABRIR UNA VES EL FORMULARIO
    public static JDesktopPane jDesktopPane;

    public DCProveedorProducto(JDesktopPane JDesktopPane) {
        DCProveedorProducto.jDesktopPane = JDesktopPane;
    }
    
    public void abrirDCProveedorProductos(JInternalFrame jInternalFrame){
        if(jInternalFrame.isVisible()){
            jInternalFrame.toFront();
            jInternalFrame.requestFocus();
        }else{
            jDesktopPane.add(jInternalFrame);
            jInternalFrame.setVisible(true);
        }
    }
    //HASTA AQUI
    

    public DCProveedorProducto(int idCompra, int idProducto, int cantidad, String descripcion) {
        this.idCompra = idCompra;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.descripcion = descripcion;
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
