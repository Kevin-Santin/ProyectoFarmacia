package com.modelo;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

/**
 *Nombre de la clase : DCProveedorMedicamentos
 * Fecha : 01.09.2019
 * CopyRight : Itca-FEPADE
 * Version : 1.0
 * @author Kevin Santin
 */
public class DCProveedorMedicamentos {
    private int idCompra;
    private int idMedicamento;
    private int cantidad;
    private String descripcion;
    //metodo constructor
    public DCProveedorMedicamentos() {
    }
    // AQUI PARA SOLO ABRIR UNA VES EL FORMULARIO
    public static JDesktopPane jDesktopPane;

    public DCProveedorMedicamentos(JDesktopPane JDesktopPane) {
        DCProveedorMedicamentos.jDesktopPane = JDesktopPane;
    }
    
    public void abrirDCProveedorMedicamentos(JInternalFrame jInternalFrame){
        if(jInternalFrame.isVisible()){
            jInternalFrame.toFront();
            jInternalFrame.requestFocus();
        }else{
            jDesktopPane.add(jInternalFrame);
            jInternalFrame.setVisible(true);
        }
    }
    //HASTA AQUI

    //Metodo Constructor con parametros
    public DCProveedorMedicamentos(int idCompra, int idMedicamento, int cantidad, String descripcion) {
        this.idCompra = idCompra;
        this.idMedicamento = idMedicamento;
        this.cantidad = cantidad;
        this.descripcion = descripcion;
    }
    //get y set
    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdMedicamento() {
        return idMedicamento;
    }

    public void setIdMedicamento(int idMedicamento) {
        this.idMedicamento = idMedicamento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }    
    
}
